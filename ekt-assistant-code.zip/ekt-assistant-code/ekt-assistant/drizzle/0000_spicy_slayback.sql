CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`cart` text DEFAULT '[]' NOT NULL,
	`pending` text,
	`revision` integer DEFAULT 0 NOT NULL,
	`last_confirmation` text,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_sessions_expires_at` ON `sessions` (`expires_at`);