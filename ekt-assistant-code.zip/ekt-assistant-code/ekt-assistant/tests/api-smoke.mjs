import assert from 'node:assert/strict';
const origin=process.env.TEST_ORIGIN||'http://localhost:5173';
const start=await fetch(origin+'/api/cart');assert.equal(start.status,200);const cookie=start.headers.get('set-cookie')?.split(';')[0];assert.ok(cookie);let checks=0;
async function post(data,opts={}){const r=await fetch(origin+'/api/cart',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin,Cookie:cookie,...opts},body:JSON.stringify(data)});const text=await r.text();let result;try{result=JSON.parse(text)}catch{result={error:text}}return {status:r.status,data:result}}
async function read(){return (await (await fetch(origin+'/api/cart',{headers:{Cookie:cookie}})).json()).cart}
assert.deepEqual(await read(),[]);checks++;
let p=await post({action:'propose',productId:515291,storeId:13,quantity:2});assert.equal(p.status,200);assert.deepEqual(await read(),[]);checks++;
assert.equal((await post({action:'confirm',proposalId:p.data.proposal.id})).status,403);assert.deepEqual(await read(),[]);checks++;
let c=await post({action:'confirm',proposalId:p.data.proposal.id,confirmation:'Да, добавить'});assert.equal(c.status,200);assert.equal(c.data.cart[0].quantity,2);checks++;
assert.equal((await post({action:'confirm',proposalId:p.data.proposal.id,confirmation:'Да, добавить'})).data.cart[0].quantity,2);checks++;
assert.equal((await post({action:'propose',productId:515291,storeId:13,quantity:4})).status,400);checks++;
assert.equal((await post({action:'propose',productId:515291,storeId:13,quantity:1.5})).status,400);checks++;
assert.equal((await post({action:'propose',productId:515288,storeId:13,quantity:1})).status,400);checks++;
assert.equal((await post({action:'propose',productId:90000001,storeId:13,quantity:1})).status,400);checks++;
assert.equal((await post({action:'propose',productId:515291,storeId:13,quantity:1},{Origin:'https://other.example'})).status,403);checks++;
assert.equal((await post({action:'confirm',proposalId:p.data.proposal.id,confirmation:'Да, добавить'},{Cookie:''})).status,409);checks++;
const old=await post({action:'propose',productId:515291,storeId:13,quantity:1});const latest=await post({action:'propose',productId:515291,storeId:13,quantity:3});assert.equal((await post({action:'confirm',proposalId:old.data.proposal.id,confirmation:'Да, добавить'})).status,409);checks++;
const concurrent=await Promise.all([1,2].map(()=>post({action:'confirm',proposalId:latest.data.proposal.id,confirmation:'Да, добавить'})));assert.ok(concurrent.some(x=>x.status===200));assert.equal((await read())[0].quantity,5);checks++;
for(const [message,check]of [['Есть ли 027228 в Алматы?',d=>d.text.includes('5 шт.')&&d.text.includes('250 А')],['Есть ли 999999?',d=>d.ids.length===0],['Покажи DEMO-A и его аналог',d=>d.ids.includes(90000002)&&d.text.includes('25 кА')],['Какие условия доставки?',d=>d.source===true],['Сертификат 027228',d=>d.text.includes('отсутствует')],['не добавляй 027228',d=>d.text.includes('Ничего не добавлено')]]){const r=await fetch(origin+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json',Origin:origin},body:JSON.stringify({message,productId:515291,storeId:13})});assert.equal(r.status,200);assert.ok(check(await r.json()),message);checks++}
const catalog=await(await fetch(origin+'/api/products?page=2&per_page=20')).json();assert.equal(catalog.items.length,20);assert.equal(catalog.items[0].id,515291);checks++;
console.log(`${checks} API checks passed: confirmation, idempotency, concurrent writes, session isolation, stock, CSRF, catalog and advisor.`);


