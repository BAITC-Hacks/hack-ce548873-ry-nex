import assert from 'node:assert/strict';
const origin=process.env.TEST_ORIGIN||'http://localhost:5173';let checks=0;
async function chat(message,lang,productId){const r=await fetch(origin+'/api/chat',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({message,lang,productId,storeId:13})});assert.equal(r.status,200);return r.json()}
for(const [lang,greet,question,add]of [['kk','Сәлем','Алматыда 027228 бар ма?','2 дана қос'],['ru','Привет','Есть ли 027228 в Алматы?','Добавь 2 шт'],['en','Hello','Is 027228 in stock in Almaty?','Add 2 units']]){
 const hello=await chat(greet,lang);assert.equal(hello.ids.length,0);assert.ok(hello.text.length>20);checks++;
 const stock=await chat(question,lang);assert.deepEqual(stock.ids,[515291]);assert.ok(stock.text.includes('5'));assert.ok(stock.texts.kk.includes('сәйкессіздік'));assert.ok(stock.texts.en.includes('conflicts'));checks++;
 const draft=await chat(add,lang,515291);assert.deepEqual(draft.draft,{productId:515291,storeId:13,quantity:2});checks++;
 const followup=await chat('2',lang,90000002);assert.deepEqual(followup.draft,{productId:90000002,storeId:13,quantity:2});checks++;
 for(const amount of ['-2','1.5','1,5','0']){const invalid=await chat(lang==='kk'?`${amount} дана қос`:lang==='ru'?`Добавь ${amount} шт`:`Add ${amount} units`,lang,90000002);assert.equal(invalid.draft,undefined);checks++;}
 const demo=await chat(lang==='kk'?'DEMO-A жоқ болса, қандай балама бар?':lang==='en'?'What alternative is available for DEMO-A?':'Какой аналог есть для DEMO-A?',lang);assert.deepEqual(demo.ids,[90000002]);assert.ok(demo.text.includes('25'));checks++;
 const unknown=await chat(lang==='en'?'Is 999999 in stock?':lang==='kk'?'999999 бар ма?':'Есть ли 999999?',lang);assert.deepEqual(unknown.ids,[]);checks++;
}
const first=await fetch(origin+'/api/cart');const cookie=first.headers.get('set-cookie').split(';')[0];
async function cart(data){const r=await fetch(origin+'/api/cart',{method:'POST',headers:{Origin:origin,Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify(data)});return {status:r.status,data:await r.json()}}
const p=await cart({action:'propose',productId:90000002,storeId:13,quantity:2});assert.equal(p.status,200);assert.equal((await cart({action:'cancel',proposalId:p.data.proposal.id})).status,200);assert.equal((await cart({action:'confirm',proposalId:p.data.proposal.id,confirmation:'Да, добавить'})).status,409);checks++;
const p2=await cart({action:'propose',productId:90000002,storeId:13,quantity:2});await cart({action:'confirm',proposalId:p2.data.proposal.id,confirmation:'Да, добавить'});assert.equal((await cart({action:'reset'})).status,403);checks++;
assert.deepEqual((await cart({action:'reset',confirmation:'CLEAR_DEMO_CART'})).data.cart,[]);assert.equal((await cart({action:'confirm',proposalId:p2.data.proposal.id,confirmation:'Да, добавить'})).status,409);checks++;
console.log(`${checks} multilingual and demo checks passed.`);
