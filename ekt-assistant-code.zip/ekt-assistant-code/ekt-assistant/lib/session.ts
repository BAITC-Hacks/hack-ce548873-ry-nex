import {env} from 'cloudflare:workers';
import {UserError,type CartLine,type Proposal} from './cart-rules';
type Row={id:string;cart:string;pending:string|null;revision:number;last_confirmation:string|null;expires_at:number};
export function database(){if(!env.DB)throw new Error('Storage unavailable');return env.DB}
export async function session(req:Request){
 const db=database(),now=Date.now();const cookie=req.headers.get('cookie')?.match(/(?:^|;\s*)ekt_session=([a-f0-9-]{36})(?:;|$)/)?.[1];
 let row=cookie?await db.prepare('SELECT * FROM sessions WHERE id = ? AND expires_at > ?').bind(cookie,now).first<Row>():null;
 let fresh=false;if(!row){fresh=true;row={id:crypto.randomUUID(),cart:'[]',pending:null,revision:0,last_confirmation:null,expires_at:now+86400000};await db.prepare('INSERT INTO sessions (id, expires_at) VALUES (?, ?)').bind(row.id,row.expires_at).run()}
 // Bounded, indexed expiry cleanup. No chat text or files are stored.
 await db.prepare('DELETE FROM sessions WHERE id IN (SELECT id FROM sessions WHERE expires_at < ? LIMIT 50)').bind(now).run();
 return {row,cart:JSON.parse(row.cart) as CartLine[],pending:row.pending?JSON.parse(row.pending) as Proposal:null,cookie:fresh?`ekt_session=${row.id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${new URL(req.url).protocol==='https:'?'; Secure':''}`:null};
}
export function json(data:unknown,status=200,cookie?:string|null){const headers:Record<string,string>={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};if(cookie)headers['Set-Cookie']=cookie;return Response.json(data,{status,headers})}
export async function body(req:Request){if(req.headers.get('origin')!==new URL(req.url).origin)throw new UserError('Запрос с другого сайта запрещён.',403);if(!req.headers.get('content-type')?.includes('application/json'))throw new UserError('Ожидается JSON.',415);if(Number(req.headers.get('content-length'))>20000)throw new UserError('Слишком большой запрос.',413);const text=await req.text();if(text.length>20000)throw new UserError('Слишком большой запрос.',413);try{return JSON.parse(text)}catch{throw new UserError('Некорректный запрос.')}}
export function failure(e:unknown){if(e instanceof UserError)return json({error:e.message},e.status);console.error('EKT request failed',e instanceof Error?e.name:'Unknown');return json({error:'Сервис временно недоступен. Ваш запрос не выполнен. Попробуйте ещё раз.'},503)}
