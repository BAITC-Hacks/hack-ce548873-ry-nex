import {findProduct} from './catalog';
export type CartLine={productId:number;storeId:number;quantity:number;price:number};
export type Proposal={id:string;productId:number;storeId:number;quantity:number;price:number;expiresAt:number};
export class UserError extends Error{constructor(message:string,public status=400){super(message)}}
export function validateLine(cart:CartLine[],productId:number,storeId:number,quantity:number){
 if(!Number.isSafeInteger(quantity)||quantity<1||quantity>9999)throw new UserError('Укажите целое количество от 1 до 9999.');
 const p=findProduct(productId);if(!p)throw new UserError('Товар не найден.');
 const stock=p.stores.find(s=>s.id===storeId);
 if(p.quantity===null||!stock)throw new UserError('Остаток на выбранном складе не подтверждён. Уточните наличие у менеджера.');
 const already=cart.filter(x=>x.productId===productId&&x.storeId===storeId).reduce((s,x)=>s+x.quantity,0);
 if(quantity+already>stock.quantity)throw new UserError(`На складе «${stock.name}» ${stock.quantity} шт.; в корзине уже ${already}. Можно добавить не более ${Math.max(0,stock.quantity-already)} шт.`);
 if(p.minimum&&quantity%p.minimum!==0)throw new UserError(`Количество должно быть кратно ${p.minimum}.`);
 return p;
}
export function applyProposal(cart:CartLine[],p:Proposal,now=Date.now()):CartLine[]{
 if(p.expiresAt<=now)throw new UserError('Подтверждение устарело. Выберите товар заново.',409);
 const product=validateLine(cart,p.productId,p.storeId,p.quantity);
 if(product.price!==p.price)throw new UserError('Цена изменилась. Нужно новое подтверждение.',409);
 const next=cart.map(x=>({...x}));const line=next.find(x=>x.productId===p.productId&&x.storeId===p.storeId);
 if(line)line.quantity+=p.quantity;else next.push({productId:p.productId,storeId:p.storeId,quantity:p.quantity,price:p.price});return next;
}
