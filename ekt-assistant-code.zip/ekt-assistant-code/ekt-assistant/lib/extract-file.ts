/** Extract locally; no original file bytes are sent to a server. */
export async function extractFile(file:File,onProgress:(s:string)=>void):Promise<string>{
 if(file.size>10*1024*1024)throw new Error('Размер файла должен быть не более 10 МБ.');
 const ext=file.name.split('.').pop()?.toLowerCase();let text='';
 if(ext==='txt'||ext==='csv')text=await file.text();
 else if(ext==='xlsx'||ext==='xls'){
  const XLSX=await import('xlsx');const wb=XLSX.read(await file.arrayBuffer(),{type:'array',sheetRows:100});
  text=wb.SheetNames.slice(0,3).map(name=>XLSX.utils.sheet_to_csv(wb.Sheets[name])).join('\n');
 }else if(ext==='docx'){
  const mammoth=await import('mammoth');text=(await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()})).value;
 }else if(ext==='pdf'){
  const pdf=await import('pdfjs-dist');pdf.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
  const task=pdf.getDocument({data:await file.arrayBuffer()});const doc=await task.promise;
  try{for(let i=1;i<=Math.min(doc.numPages,10);i++){const page=await doc.getPage(i);const content=await page.getTextContent();text+=content.items.map((x:any)=>x.str||'').join(' ')+'\n'}}finally{await task.destroy()}
  if(!text.trim())throw new Error('В PDF нет текстового слоя. Загрузите нужную страницу как JPEG для распознавания.');
 }else if(['jpg','jpeg','png'].includes(ext||'')){
  const bitmap=await createImageBitmap(file);const pixels=bitmap.width*bitmap.height;bitmap.close();if(pixels>16000000)throw new Error('Уменьшите изображение до 16 мегапикселей.');
  onProgress('Распознаю изображение. Первая загрузка языков может занять до минуты…');
  const {createWorker}=await import('tesseract.js');const worker=await createWorker('rus+eng');
  try{text=(await worker.recognize(file)).data.text}finally{await worker.terminate()}
 }else throw new Error('Поддерживаются XLSX, XLS, DOCX, PDF, JPEG, PNG, TXT и CSV. Сохраните старый Word-файл как DOCX.');
 if(!text.trim())throw new Error('Текст не найден. Введите артикул вручную.');
 return text.trim().slice(0,2000);
}
