import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const sessions=sqliteTable('sessions',{
 id:text('id').primaryKey(),cart:text('cart').notNull().default('[]'),pending:text('pending'),revision:integer('revision').notNull().default(0),lastConfirmation:text('last_confirmation'),expiresAt:integer('expires_at').notNull()
},t=>[index('idx_sessions_expires_at').on(t.expiresAt)]);
