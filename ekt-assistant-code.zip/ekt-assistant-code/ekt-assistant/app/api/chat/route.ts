import {body,json,failure} from '@/lib/session';
import {UserError} from '@/lib/cart-rules';
import {adviseLocalized} from '@/lib/advisor-v2';
import {interpret} from '@/lib/llm';
export async function POST(req:Request){try{
 const b=await body(req);if(typeof b.message!=='string'||!b.message.trim()||b.message.length>2000)throw new UserError('Сообщение должно содержать от 1 до 2000 символов.');
 const lang=b.lang==='kk'||b.lang==='en'?b.lang:'ru';let interpreted:string|null=null;try{interpreted=await interpret(b.message,b.history)}catch{}
 let query=b.message;let result=adviseLocalized(query,Number(b.productId),Number(b.storeId),lang);let mode='rules';
 if(interpreted&&!result.ids.length&&!result.source){query=interpreted;result=adviseLocalized(query,Number(b.productId),Number(b.storeId),lang);result.draft=undefined;mode='llm'}
 const texts=Object.fromEntries((['kk','ru','en'] as const).map(l=>[l,adviseLocalized(query,Number(b.productId),Number(b.storeId),l).text]));
 return json({...result,texts,mode});
}catch(e){return failure(e)}}
