import {database,session,json,body,failure} from '@/lib/session';
import {validateLine,applyProposal,UserError,type Proposal} from '@/lib/cart-rules';
export async function GET(req:Request){try{const s=await session(req);return json({cart:s.cart},200,s.cookie)}catch(e){return failure(e)}}
export async function POST(req:Request){try{
 const b=await body(req),s=await session(req),db=database();
 if(b.action==='reset'){
  if(b.confirmation!=='CLEAR_DEMO_CART')throw new UserError('Нужно явное подтверждение.',403);
  const r=await db.prepare('UPDATE sessions SET cart = ?, pending = NULL, last_confirmation = NULL, revision = revision + 1 WHERE id = ? AND revision = ?').bind('[]',s.row.id,s.row.revision).run();
  if(!r.meta.changes)throw new UserError('Корзина изменилась. Повторите действие.',409);
  return json({cart:[]},200,s.cookie);
 }
 if(b.action==='cancel'){
  if(s.pending?.id===b.proposalId)await db.prepare('UPDATE sessions SET pending = NULL, revision = revision + 1 WHERE id = ? AND revision = ?').bind(s.row.id,s.row.revision).run();
  return json({cancelled:true},200,s.cookie);
 }
 if(b.action==='propose'){
  const p=validateLine(s.cart,b.productId,b.storeId,b.quantity);
  const proposal:Proposal={id:crypto.randomUUID(),productId:p.id,storeId:b.storeId,quantity:b.quantity,price:p.price,expiresAt:Date.now()+300000};
  const r=await db.prepare('UPDATE sessions SET pending = ?, revision = revision + 1 WHERE id = ? AND revision = ?').bind(JSON.stringify(proposal),s.row.id,s.row.revision).run();
  if(!r.meta.changes)throw new UserError('Корзина изменилась. Повторите выбор.',409);
  return json({proposal},200,s.cookie);
 }
 if(b.action==='confirm'){
  if(b.confirmation!=='Да, добавить')throw new UserError('Нужно явное подтверждение «Да, добавить».',403);
  if(typeof b.proposalId!=='string')throw new UserError('Не указано подтверждение.');
  if(s.row.last_confirmation===b.proposalId)return json({cart:s.cart,replayed:true},200,s.cookie);
  if(!s.pending||s.pending.id!==b.proposalId)throw new UserError('Нет активного предложения. Выберите товар заново.',409);
  const next=applyProposal(s.cart,s.pending);
  const r=await db.prepare('UPDATE sessions SET cart = ?, pending = NULL, last_confirmation = ?, revision = revision + 1 WHERE id = ? AND revision = ? AND pending = ?').bind(JSON.stringify(next),b.proposalId,s.row.id,s.row.revision,s.row.pending).run();
  if(!r.meta.changes)throw new UserError('Корзина изменилась. Обновите её перед подтверждением.',409);
  return json({cart:next,cartUrl:'/#cart'},200,s.cookie);
 }
 throw new UserError('Неизвестное действие.');
}catch(e){return failure(e)}}
