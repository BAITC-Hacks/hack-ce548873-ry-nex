import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EKT · ЖИ-көмекші",
  description: "Электр тауарларының каталогы және қазақ, орыс, ағылшын тілдеріндегі көмекші.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="kk">
      <body className="antialiased">{children}</body>
    </html>
  );
}
